﻿
using Models.Interfaces;
namespace Repository.Interfaces
{
    public interface IModelRepository : ICrudRepository<Models.Model,IModel>
    {
    }
}
