﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CSharpAndMySQLApi.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpAndMySQLApi.Controllers.Tests
{
    [TestClass()]
    public class ValuesControllerTests
    {
        [TestMethod()]
        public void GetTest()
        {
            Assert.Fail();
        }
    }
}