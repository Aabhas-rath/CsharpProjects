﻿namespace Models.Interfaces
{
    public interface IModel
    {
        int Id { get; set; }
    }
}
