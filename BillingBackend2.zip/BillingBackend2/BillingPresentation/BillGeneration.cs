﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BillingBusinessLogic;
using Billing.Models;
using System.Collections.Specialized;
using System.Text.RegularExpressions;

namespace BillingPresentation
{
    public partial class BillGeneration : Form
    {
        private AdvertisementBill _bill;
        private int _noOfProducts = 0;
        private bool _EditConfig = false;
        private Button _btnSaveConfig;
        private BillPageGenerator _generator;
        private string _billsaveplace;
        private string _TemplatePath;
        private Configuration _Config = null;
        private string _logsBasePath;

        public BillGeneration()
        {
            InitializeComponent();
            init();
        }
        public BillGeneration(AdvertisementBill Bill)
        {
            _bill = Bill;
            InitializeComponent();
            init();
        }

        private void init()
        {
            NameValueCollection appsettings = System.Configuration.ConfigurationManager.AppSettings;
            _Config = new Billing.Models.Configuration(appsettings["BankName"], appsettings["AccountNumber"], appsettings["IFSCCode"],
                Convert.ToInt32(appsettings["BranchNumber"]), appsettings["CompanyName"], string.IsNullOrEmpty(appsettings["PANCode"]) ? "" : appsettings["PANCode"],
                string.IsNullOrEmpty(appsettings["GSTNo"]) ? "" : appsettings["GSTNo"]);
            assignConfigValues(_Config);
            _TemplatePath = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Application.ExecutablePath), "Templates", appsettings["TemplateName"].ToString());
            _billsaveplace = appsettings["BillSavePath"];
            _logsBasePath = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Application.ExecutablePath), appsettings["LogsBasePath"].ToString());
            txtbxConfigAccountNo.Enabled = false;
            txtbxConfigBankName.Enabled = false;
            txtbxConfigBranchCode.Enabled = false;
            txtbxConfigCompanyName.Enabled = false;
            txtbxConfigGSTNo.Enabled = false;
            txtbxConfigIFSCCode.Enabled = false;
            txtbxConfigPanNo.Enabled = false;
            
        }

        private void assignConfigValues(Billing.Models.Configuration c)
        {
            txtbxConfigAccountNo.Text = c.BankAccountNumber;
            txtbxConfigBankName.Text = c.BankName;
            txtbxConfigBranchCode.Text = c.BranchNumber.ToString();
            txtbxConfigCompanyName.Text = c.CompanyName;
            txtbxConfigGSTNo.Text = c.GSTNo;
            txtbxConfigIFSCCode.Text = c.IFSCCode;
            txtbxConfigPanNo.Text = c.PANCode;
        }
        private void BillGeneration_Load(object sender, EventArgs e)
        {

        }
        private void BillGeneration_FormClosing(object sender, FormClosingEventArgs e)
        {
            ParentForm.Close();
        }
        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            int productRow = 8 + _noOfProducts;
            TextBox txtbxProductName = new TextBox();
            txtbxProductName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            txtbxProductName.Location = new System.Drawing.Point(822, 90);
            txtbxProductName.Name = "txtbxProduct" + _noOfProducts + "Name";
            txtbxProductName.Size = new System.Drawing.Size(182, 22);
            txtbxProductName.TabIndex = 0;


            TextBox txtbxFromToViews = new TextBox();
            txtbxFromToViews.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            txtbxFromToViews.Location = new System.Drawing.Point(822, 90);
            txtbxFromToViews.Name = "txtbxFromToViews" + _noOfProducts;
            txtbxFromToViews.Size = new System.Drawing.Size(182, 22);
            txtbxFromToViews.TabIndex = 0;

            TextBox txtbxProductRate = new TextBox();
            txtbxProductRate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            txtbxProductRate.Location = new System.Drawing.Point(822, 90);
            txtbxProductRate.Name = "txtbxProduct" + _noOfProducts + "Rate";
            txtbxProductRate.Size = new System.Drawing.Size(182, 22);
            txtbxProductRate.TabIndex = 0;

            TextBox txtbxProductTotalAmount = new TextBox();
            txtbxProductTotalAmount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            txtbxProductTotalAmount.Location = new System.Drawing.Point(822, 90);
            txtbxProductTotalAmount.Name = "txtbxProduct" + _noOfProducts + "TotalAmount";
            txtbxProductTotalAmount.Size = new System.Drawing.Size(182, 22);
            txtbxProductTotalAmount.TabIndex = 0;

            Button RemoveButton = new Button();
            RemoveButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            RemoveButton.AutoSize = true;
            RemoveButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            RemoveButton.Location = new System.Drawing.Point(1256, 227);
            RemoveButton.Name = "Remove" + productRow;
            RemoveButton.Size = new System.Drawing.Size(70, 22);
            RemoveButton.TabIndex = 3;
            RemoveButton.Text = "Remove";
            RemoveButton.UseMnemonic = false;
            RemoveButton.UseVisualStyleBackColor = true;
            RemoveButton.CausesValidation = false;
            RemoveButton.Click += RemoveButton_Click;

            RowStyle rowStyle = tableLayoutPanel1.RowStyles[8];
            tableLayoutPanel1.Visible = false;
            tableLayoutPanel1.RowStyles.Insert(productRow, new RowStyle(rowStyle.SizeType, rowStyle.Height));

            foreach (Control ExistControl in tableLayoutPanel1.Controls)
            {
                if (tableLayoutPanel1.GetRow(ExistControl) >= productRow)
                {
                    tableLayoutPanel1.SetRow(ExistControl,
                                            tableLayoutPanel1.GetRow(ExistControl) + 1);
                }
            }
            tableLayoutPanel1.Controls.Add(txtbxProductName, 1, productRow);
            tableLayoutPanel1.Controls.Add(txtbxProductTotalAmount, 5, productRow);
            tableLayoutPanel1.Controls.Add(txtbxFromToViews, 3, productRow);
            tableLayoutPanel1.Controls.Add(txtbxProductRate, 4, productRow);
            tableLayoutPanel1.Controls.Add(RemoveButton, 6, productRow);
            tableLayoutPanel1.SetColumnSpan(txtbxProductName, 2);
            _noOfProducts++;

            lblDescription.Visible = true;
            lblAmount.Visible = true;
            lblInsertions.Visible = true;
            lblRate.Visible = true;
            tableLayoutPanel1.Refresh();
            tableLayoutPanel1.Visible = true;
        }
        private void RemoveRow(int row)
        {
            //tableLayoutPanel1.Visible = false;
            for (int i = 2; i < 7; i++)
            {
                Control c;
                if (i == 2)
                {
                    c = tableLayoutPanel1.GetControlFromPosition(1, row);
                }
                else
                    c = tableLayoutPanel1.GetControlFromPosition(i, row);
                tableLayoutPanel1.Controls.Remove(c);
            }
            _noOfProducts--;

            foreach (Control ExistControl in tableLayoutPanel1.Controls)
            {
                if (tableLayoutPanel1.GetRow(ExistControl) >= row)
                {
                    tableLayoutPanel1.SetRow(ExistControl,
                                            tableLayoutPanel1.GetRow(ExistControl) - 1);
                }
            }
            tableLayoutPanel1.RowCount--;
            if (_noOfProducts == 0 && row == 8)
            {
                lblDescription.Visible = !true;
                lblAmount.Visible = !true;
                lblInsertions.Visible = !true;
                lblRate.Visible = !true;
            }
            tableLayoutPanel1.Refresh();
            tableLayoutPanel1.Visible = true;
        }
        private void RemoveButton_Click(object sender, EventArgs e)
        {

            int col = tableLayoutPanel1.GetColumn((Control)sender);
            int row = tableLayoutPanel1.GetRow((Control)sender);
            RemoveRow(row);
        }

        private void btnEditConfig_Click(object sender, EventArgs e)
        {
            if (!_EditConfig)
            {
                _EditConfig = !_EditConfig;
                txtbxConfigAccountNo.Enabled = true;
                txtbxConfigBankName.Enabled = true;
                txtbxConfigBranchCode.Enabled = true;
                txtbxConfigCompanyName.Enabled = true;
                txtbxConfigGSTNo.Enabled = true;
                txtbxConfigIFSCCode.Enabled = true;
                txtbxConfigPanNo.Enabled = true;
                btnEditConfig.Visible = false;
                int row = tableLayoutPanel1.GetRow((Control)sender);
                int col = tableLayoutPanel1.GetColumn((Control)sender);
                
                if (_btnSaveConfig == null)
                {

                    _btnSaveConfig = new Button();
                    _btnSaveConfig.Anchor = System.Windows.Forms.AnchorStyles.None;
                    _btnSaveConfig.Location = new System.Drawing.Point(377, 598);
                    _btnSaveConfig.Name = "btnSaveConfig";
                    _btnSaveConfig.Size = new System.Drawing.Size(144, 25);
                    _btnSaveConfig.TabIndex = 2;
                    _btnSaveConfig.Text = "Save";
                    _btnSaveConfig.UseVisualStyleBackColor = true;
                    _btnSaveConfig.CausesValidation = false;
                    _btnSaveConfig.Click += BtnSaveConfig_Click;
                    tableLayoutPanel1.Controls.Add(_btnSaveConfig, col, row);
                }
                _btnSaveConfig.Visible = true;
            }



        }

        private void BtnSaveConfig_Click(object sender, EventArgs e)
        {
            _Config = new Configuration(
                txtbxConfigBankName.Text,
                txtbxConfigAccountNo.Text,
                txtbxConfigIFSCCode.Text,
                Convert.ToInt32(txtbxConfigBranchCode.Text),
                txtbxConfigCompanyName.Text,
                txtbxConfigPanNo.Text,
                txtbxGSTTin.Text);
            _EditConfig = !_EditConfig;

            txtbxConfigAccountNo.Enabled = false;
            txtbxConfigBankName.Enabled = false;
            txtbxConfigBranchCode.Enabled = false;
            txtbxConfigCompanyName.Enabled = false;
            txtbxConfigGSTNo.Enabled = false;
            txtbxConfigIFSCCode.Enabled = false;
            txtbxConfigPanNo.Enabled = false;

            _btnSaveConfig.Visible = false;
            btnEditConfig.Visible = true;
        }
        private void btnRemoveAll_Click(object sender, EventArgs e)
        {
            int baseRow = 8, products = _noOfProducts;
            if (_noOfProducts == 0)
            {
                return;
            }

            for (int i = 0; i < products; i++)
            {
                RemoveRow(baseRow);
            }
        }
        private BaseProduct CreateProduct(int row)
        {
            string description = (tableLayoutPanel1.GetControlFromPosition(1, row) as TextBox).Text;
            string Insertion = (tableLayoutPanel1.GetControlFromPosition(3, row) as TextBox).Text;
            string Rate = (tableLayoutPanel1.GetControlFromPosition(4, row) as TextBox).Text;
            string Amount = (tableLayoutPanel1.GetControlFromPosition(5, row) as TextBox).Text;
            BaseProduct returnProduct;
            int quan=1;
            double rate;
            if (Rate.ToLower().Contains("x"))
            {
                quan = Convert.ToInt32(Rate.Split('x')[0]);
                rate = Convert.ToDouble(Rate.Split('x')[1]);
            }
            else
                rate = Convert.ToDouble(Rate);
            
            if (Insertion.ToLower().Contains("views")|| Insertion.ToLower().Contains("view"))
            {
                returnProduct =new AdSpacePerViews(description,quan,rate,String.IsNullOrEmpty(Amount)? (rate * quan) : Convert.ToDouble(Amount),Convert.ToInt32(Insertion.Split(':')[1]));
            }
            else
            {
                string[] vs = Insertion.ToLower().Split(' ');

                DateTime from = DateTime.ParseExact(vs[0].Split(':')[1],"dd/MM/yyyy",null);
                DateTime to = DateTime.ParseExact(vs[1].Split(':')[1],"dd/MM/yyyy",null);

                returnProduct = new AdSpacePerTime(description, quan, rate, Convert.ToDouble(Amount),from,to);

            }
            return returnProduct;
        }
        private void btnSaveBill_Click(object sender, EventArgs e)
        {
            if (ValidateChildren(ValidationConstraints.Enabled))
            {
                _bill = new AdvertisementBill();
                _bill.Name = txtbxCustomerName.Text;
                _bill.Address = txtbxAddress.Text;
                _bill.GSTNo = (string.IsNullOrEmpty(txtbxGSTTin.Text) ? "" : txtbxGSTTin.Text);
                _bill.ClientName = txtbxClientName.Text;
                _bill.PublicationDate = dtpPubDate.Value;
                _bill.InvoiceNumber = txtbxInvoiceNo.Text;
                _bill.PaymentTerm = cbPaymentTerm.SelectedItem.ToString();
                _bill.ReleaseOrderNo = txtbxReleaseOrder.Text;
                _bill.InvoiceDate = DateTime.Today;
                int productBaseRow = 8;
                for (int i = 0; i < _noOfProducts; i++)
                {
                    _bill.AddProductToProductsList(CreateProduct(productBaseRow + i));
                }


                _bill.AgencyDiscount = string.IsNullOrEmpty(txtbxAgencyDiscount.Text) ? 0 : Convert.ToInt32(txtbxAgencyDiscount.Text);
                _bill.CGST= Convert.ToDouble(string.IsNullOrEmpty(txtbxCgst.Text) ? CalculateCGST(_bill as AdvertisementBill) : txtbxCgst.Text);
                _bill.SGST = Convert.ToDouble(string.IsNullOrEmpty(txtbxSGST.Text) ? CalculateSGST(_bill as AdvertisementBill) : txtbxSGST.Text);
                _bill.IGST = Convert.ToDouble(string.IsNullOrEmpty(txtbxIgst.Text) ? CalculateIGST(_bill as AdvertisementBill) : txtbxIgst.Text);
                _bill.TotalBill = CalculateTotalBill(_bill as AdvertisementBill);
                txtbxCgst.Text = _bill.CGST.ToString();
                _bill.BillType = "Advertisement";

                _generator = new BillPageGenerator();
                _generator.AssociatedBill = _bill;
                _generator.Config = _Config;
                _generator.BillSavePath = _billsaveplace;
                _generator.BillTemplatePath = _TemplatePath;
                _generator.ConvertFileType = ConvertFileType.PDF;
                _generator.LogBasePath = _logsBasePath;
                _generator.LoadTemplate();

                _generator.SaveBillAs(_generator.GenerateBillByTemplate());


            }
        }

        private int CalculateTotalBill(AdvertisementBill advertisementBill)
        {
            double Total=0;
            foreach (var pr in _bill.Products)
            {
                Total += pr.TotalAmount;
            }
            Total += _bill.CGST;
            Total += _bill.SGST;
            Total += _bill.IGST;

            if (_bill.AgencyDiscount!=0)
            {
                Total = ((double)_bill.AgencyDiscount / 100D) * Total;
            }
            
            return (int)Total;
        }

        private string CalculateCGST(AdvertisementBill bill)
        {
            double Total = 0;
            foreach (var pr in bill.Products)
            {
                Total += pr.TotalAmount;
            }
            return (Total * 0.09).ToString();
        }
        private string CalculateSGST(AdvertisementBill bill)
        {
            double Total = 0;
            foreach (var pr in bill.Products)
            {
                Total += pr.TotalAmount;
            }
            return (Total * 0.09).ToString();
        }
        private string CalculateIGST(AdvertisementBill bill)
        {
            double Total = 0;
            foreach (var pr in bill.Products)
            {
                Total += pr.TotalAmount;
            }
            return (Total * 0.18).ToString();
        }
        private void btnSaveBill_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtbxCustomerName.Text))
            {
                e.Cancel = true;
                txtbxCustomerName.Focus();
                BillValidator.SetError(txtbxCustomerName, "Cannot have Customer Name Empty");
            }
            if (string.IsNullOrEmpty(txtbxAddress.Text))
            {
                e.Cancel = true;
                txtbxAddress.Focus();
                BillValidator.SetError(txtbxAddress, "Cannot have Address Empty");
            }
            if (string.IsNullOrEmpty(txtbxClientName.Text))
            {
                e.Cancel = true;
                txtbxClientName.Focus();
                BillValidator.SetError(txtbxClientName, "Cannot have Client/Agent Name Empty");
            }
            if (DateTime.Today.Subtract(dtpPubDate.Value).TotalDays>7300)
            {
                e.Cancel = true;
                dtpPubDate.Focus();
                BillValidator.SetError(dtpPubDate, "Old Publication date. Please Verify");
            }
            if (string.IsNullOrEmpty(txtbxInvoiceNo.Text))
            {
                e.Cancel = true;
                txtbxInvoiceNo.Focus();
                BillValidator.SetError(txtbxInvoiceNo, "Cannot have Invoice Number Empty");
            }
            if (string.IsNullOrEmpty(txtbxReleaseOrder.Text))
            {
                e.Cancel = true;
                txtbxReleaseOrder.Focus();
                BillValidator.SetError(txtbxReleaseOrder, "Bill won't release if you dont have a release order number");
            }
            if (string.IsNullOrEmpty(cbPaymentTerm.SelectedItem.ToString()))
            {
                e.Cancel = true;
                cbPaymentTerm.Focus();
                BillValidator.SetError(cbPaymentTerm, "please enter a Payment Term");
            }
            if (_noOfProducts==0)
            {
                e.Cancel = true;
                btnAddProduct.Focus();
                BillValidator.SetError(btnAddProduct, "Kindly add a product before continuing");
            }
        }
    }
}
