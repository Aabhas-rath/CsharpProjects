﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BillingPresentation
{
    public partial class MainPage : Form
    {
        
        public MainPage()
        {
            InitializeComponent();
        }


        private void MainPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            ParentForm.Close();
        }

        private void btnNewBill_Click(object sender, EventArgs e)
        {
            BillGeneration mainPage = new BillGeneration();
            mainPage.Show();
            this.Hide();
        }
    }
}
