﻿namespace BillingPresentation
{
    partial class BillGeneration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.txtbxInvoiceNo = new System.Windows.Forms.TextBox();
            this.txtbxReleaseOrder = new System.Windows.Forms.TextBox();
            this.txtbxCustomerName = new System.Windows.Forms.TextBox();
            this.txtbxAddress = new System.Windows.Forms.TextBox();
            this.txtbxGSTTin = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtbxClientName = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtbxTotalAmount = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtbxIgst = new System.Windows.Forms.TextBox();
            this.txtbxSGST = new System.Windows.Forms.TextBox();
            this.txtbxCgst = new System.Windows.Forms.TextBox();
            this.txtbxAgencyDiscount = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblInsertions = new System.Windows.Forms.Label();
            this.lblRate = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtbxConfigCompanyName = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtbxConfigBankName = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtbxConfigBranchCode = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtbxConfigAccountNo = new System.Windows.Forms.TextBox();
            this.txtbxConfigIFSCCode = new System.Windows.Forms.TextBox();
            this.txtbxConfigPanNo = new System.Windows.Forms.TextBox();
            this.txtbxConfigGSTNo = new System.Windows.Forms.TextBox();
            this.btnEditConfig = new System.Windows.Forms.Button();
            this.btnRemoveAll = new System.Windows.Forms.Button();
            this.btnSaveBill = new System.Windows.Forms.Button();
            this.dtpPubDate = new System.Windows.Forms.DateTimePicker();
            this.cbPaymentTerm = new System.Windows.Forms.ComboBox();
            this.BillValidator = new System.Windows.Forms.ErrorProvider(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BillValidator)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.ColumnCount = 7;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 2.743682F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.93863F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.05054F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 13.86282F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.83393F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.8231F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9.891697F));
            this.tableLayoutPanel1.Controls.Add(this.txtbxInvoiceNo, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtbxReleaseOrder, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtbxCustomerName, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtbxAddress, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtbxGSTTin, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label4, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label5, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.label6, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.label7, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.label8, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtbxClientName, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.label20, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.label21, 4, 14);
            this.tableLayoutPanel1.Controls.Add(this.txtbxTotalAmount, 5, 14);
            this.tableLayoutPanel1.Controls.Add(this.label22, 4, 13);
            this.tableLayoutPanel1.Controls.Add(this.txtbxIgst, 5, 13);
            this.tableLayoutPanel1.Controls.Add(this.txtbxSGST, 5, 12);
            this.tableLayoutPanel1.Controls.Add(this.txtbxCgst, 5, 11);
            this.tableLayoutPanel1.Controls.Add(this.txtbxAgencyDiscount, 5, 10);
            this.tableLayoutPanel1.Controls.Add(this.label23, 4, 12);
            this.tableLayoutPanel1.Controls.Add(this.label24, 4, 11);
            this.tableLayoutPanel1.Controls.Add(this.label25, 4, 10);
            this.tableLayoutPanel1.Controls.Add(this.btnAddProduct, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.lblDescription, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblInsertions, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblRate, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.lblAmount, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.label13, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.txtbxConfigCompanyName, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.label14, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.txtbxConfigBankName, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.label15, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.txtbxConfigBranchCode, 2, 13);
            this.tableLayoutPanel1.Controls.Add(this.label16, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.label17, 1, 15);
            this.tableLayoutPanel1.Controls.Add(this.label18, 1, 16);
            this.tableLayoutPanel1.Controls.Add(this.label19, 1, 17);
            this.tableLayoutPanel1.Controls.Add(this.txtbxConfigAccountNo, 2, 14);
            this.tableLayoutPanel1.Controls.Add(this.txtbxConfigIFSCCode, 2, 15);
            this.tableLayoutPanel1.Controls.Add(this.txtbxConfigPanNo, 2, 16);
            this.tableLayoutPanel1.Controls.Add(this.txtbxConfigGSTNo, 2, 17);
            this.tableLayoutPanel1.Controls.Add(this.btnEditConfig, 2, 18);
            this.tableLayoutPanel1.Controls.Add(this.btnRemoveAll, 6, 9);
            this.tableLayoutPanel1.Controls.Add(this.dtpPubDate, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.cbPaymentTerm, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.btnSaveBill, 5, 17);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 20;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.166667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.974843F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.515723F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.245283F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1385, 664);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // txtbxInvoiceNo
            // 
            this.txtbxInvoiceNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxInvoiceNo.Location = new System.Drawing.Point(1015, 71);
            this.txtbxInvoiceNo.Name = "txtbxInvoiceNo";
            this.txtbxInvoiceNo.Size = new System.Drawing.Size(226, 22);
            this.txtbxInvoiceNo.TabIndex = 0;
            // 
            // txtbxReleaseOrder
            // 
            this.txtbxReleaseOrder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxReleaseOrder.Location = new System.Drawing.Point(1015, 104);
            this.txtbxReleaseOrder.Name = "txtbxReleaseOrder";
            this.txtbxReleaseOrder.Size = new System.Drawing.Size(226, 22);
            this.txtbxReleaseOrder.TabIndex = 0;
            // 
            // txtbxCustomerName
            // 
            this.txtbxCustomerName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxCustomerName.Location = new System.Drawing.Point(329, 104);
            this.txtbxCustomerName.Name = "txtbxCustomerName";
            this.txtbxCustomerName.Size = new System.Drawing.Size(243, 22);
            this.txtbxCustomerName.TabIndex = 0;
            // 
            // txtbxAddress
            // 
            this.txtbxAddress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxAddress.Location = new System.Drawing.Point(329, 137);
            this.txtbxAddress.Name = "txtbxAddress";
            this.txtbxAddress.Size = new System.Drawing.Size(243, 22);
            this.txtbxAddress.TabIndex = 0;
            // 
            // txtbxGSTTin
            // 
            this.txtbxGSTTin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxGSTTin.Location = new System.Drawing.Point(329, 170);
            this.txtbxGSTTin.Name = "txtbxGSTTin";
            this.txtbxGSTTin.Size = new System.Drawing.Size(243, 22);
            this.txtbxGSTTin.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(283, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "To,";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(283, 33);
            this.label2.TabIndex = 1;
            this.label2.Text = "AGENCY  NAME :-";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(283, 33);
            this.label3.TabIndex = 1;
            this.label3.Text = "Address";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(283, 33);
            this.label4.TabIndex = 1;
            this.label4.Text = "GST";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(769, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(240, 33);
            this.label5.TabIndex = 1;
            this.label5.Text = "Publication Date";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(769, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(240, 33);
            this.label6.TabIndex = 1;
            this.label6.Text = "Invoice No";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(769, 99);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(240, 33);
            this.label7.TabIndex = 1;
            this.label7.Text = "Release Order No";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(769, 132);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(240, 33);
            this.label8.TabIndex = 1;
            this.label8.Text = "Payment Term";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbxClientName
            // 
            this.txtbxClientName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxClientName.Location = new System.Drawing.Point(329, 203);
            this.txtbxClientName.Name = "txtbxClientName";
            this.txtbxClientName.Size = new System.Drawing.Size(243, 22);
            this.txtbxClientName.TabIndex = 0;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(40, 198);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(283, 33);
            this.label20.TabIndex = 1;
            this.label20.Text = "Client name";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(769, 462);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(240, 33);
            this.label21.TabIndex = 1;
            this.label21.Text = "Total";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbxTotalAmount
            // 
            this.txtbxTotalAmount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxTotalAmount.Location = new System.Drawing.Point(1015, 467);
            this.txtbxTotalAmount.Name = "txtbxTotalAmount";
            this.txtbxTotalAmount.Size = new System.Drawing.Size(226, 22);
            this.txtbxTotalAmount.TabIndex = 0;
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(769, 429);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(240, 33);
            this.label22.TabIndex = 1;
            this.label22.Text = "IGST";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbxIgst
            // 
            this.txtbxIgst.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxIgst.Location = new System.Drawing.Point(1015, 434);
            this.txtbxIgst.Name = "txtbxIgst";
            this.txtbxIgst.Size = new System.Drawing.Size(226, 22);
            this.txtbxIgst.TabIndex = 0;
            // 
            // txtbxSGST
            // 
            this.txtbxSGST.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxSGST.Location = new System.Drawing.Point(1015, 401);
            this.txtbxSGST.Name = "txtbxSGST";
            this.txtbxSGST.Size = new System.Drawing.Size(226, 22);
            this.txtbxSGST.TabIndex = 0;
            // 
            // txtbxCgst
            // 
            this.txtbxCgst.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxCgst.Location = new System.Drawing.Point(1015, 368);
            this.txtbxCgst.Name = "txtbxCgst";
            this.txtbxCgst.Size = new System.Drawing.Size(226, 22);
            this.txtbxCgst.TabIndex = 0;
            // 
            // txtbxAgencyDiscount
            // 
            this.txtbxAgencyDiscount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxAgencyDiscount.Location = new System.Drawing.Point(1015, 335);
            this.txtbxAgencyDiscount.Name = "txtbxAgencyDiscount";
            this.txtbxAgencyDiscount.Size = new System.Drawing.Size(226, 22);
            this.txtbxAgencyDiscount.TabIndex = 0;
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(769, 396);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(240, 33);
            this.label23.TabIndex = 1;
            this.label23.Text = "SGST";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(769, 363);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(240, 33);
            this.label24.TabIndex = 1;
            this.label24.Text = "CGST";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(769, 330);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(240, 33);
            this.label25.TabIndex = 1;
            this.label25.Text = "Agency Discount";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAddProduct.CausesValidation = false;
            this.btnAddProduct.Location = new System.Drawing.Point(130, 301);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(103, 25);
            this.btnAddProduct.TabIndex = 2;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // lblDescription
            // 
            this.lblDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(329, 231);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(243, 33);
            this.lblDescription.TabIndex = 1;
            this.lblDescription.Text = "Description";
            this.lblDescription.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDescription.Visible = false;
            // 
            // lblInsertions
            // 
            this.lblInsertions.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblInsertions.AutoSize = true;
            this.lblInsertions.Location = new System.Drawing.Point(578, 231);
            this.lblInsertions.Name = "lblInsertions";
            this.lblInsertions.Size = new System.Drawing.Size(185, 33);
            this.lblInsertions.TabIndex = 1;
            this.lblInsertions.Text = "Insertions";
            this.lblInsertions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblInsertions.Visible = false;
            // 
            // lblRate
            // 
            this.lblRate.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblRate.AutoSize = true;
            this.lblRate.Location = new System.Drawing.Point(769, 231);
            this.lblRate.Name = "lblRate";
            this.lblRate.Size = new System.Drawing.Size(240, 33);
            this.lblRate.TabIndex = 1;
            this.lblRate.Text = "Rate";
            this.lblRate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRate.Visible = false;
            // 
            // lblAmount
            // 
            this.lblAmount.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(1015, 231);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(226, 33);
            this.lblAmount.TabIndex = 1;
            this.lblAmount.Text = "Amount";
            this.lblAmount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAmount.Visible = false;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(40, 363);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(283, 33);
            this.label13.TabIndex = 1;
            this.label13.Text = "Company name";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbxConfigCompanyName
            // 
            this.txtbxConfigCompanyName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxConfigCompanyName.Location = new System.Drawing.Point(329, 368);
            this.txtbxConfigCompanyName.Name = "txtbxConfigCompanyName";
            this.txtbxConfigCompanyName.Size = new System.Drawing.Size(243, 22);
            this.txtbxConfigCompanyName.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(40, 396);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(283, 33);
            this.label14.TabIndex = 1;
            this.label14.Text = "Bank";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbxConfigBankName
            // 
            this.txtbxConfigBankName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxConfigBankName.Location = new System.Drawing.Point(329, 401);
            this.txtbxConfigBankName.Name = "txtbxConfigBankName";
            this.txtbxConfigBankName.Size = new System.Drawing.Size(243, 22);
            this.txtbxConfigBankName.TabIndex = 0;
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(40, 429);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(283, 33);
            this.label15.TabIndex = 1;
            this.label15.Text = "Branch Code";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbxConfigBranchCode
            // 
            this.txtbxConfigBranchCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxConfigBranchCode.Location = new System.Drawing.Point(329, 434);
            this.txtbxConfigBranchCode.Name = "txtbxConfigBranchCode";
            this.txtbxConfigBranchCode.Size = new System.Drawing.Size(243, 22);
            this.txtbxConfigBranchCode.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(40, 462);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(283, 33);
            this.label16.TabIndex = 1;
            this.label16.Text = "Bank Account No.";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(40, 495);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(283, 33);
            this.label17.TabIndex = 1;
            this.label17.Text = "IFSC Code ";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(40, 528);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(283, 33);
            this.label18.TabIndex = 1;
            this.label18.Text = "Pan no. ";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(40, 561);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(283, 33);
            this.label19.TabIndex = 1;
            this.label19.Text = "GST NO";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtbxConfigAccountNo
            // 
            this.txtbxConfigAccountNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxConfigAccountNo.Location = new System.Drawing.Point(329, 467);
            this.txtbxConfigAccountNo.Name = "txtbxConfigAccountNo";
            this.txtbxConfigAccountNo.Size = new System.Drawing.Size(243, 22);
            this.txtbxConfigAccountNo.TabIndex = 0;
            // 
            // txtbxConfigIFSCCode
            // 
            this.txtbxConfigIFSCCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxConfigIFSCCode.Location = new System.Drawing.Point(329, 500);
            this.txtbxConfigIFSCCode.Name = "txtbxConfigIFSCCode";
            this.txtbxConfigIFSCCode.Size = new System.Drawing.Size(243, 22);
            this.txtbxConfigIFSCCode.TabIndex = 0;
            // 
            // txtbxConfigPanNo
            // 
            this.txtbxConfigPanNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxConfigPanNo.Location = new System.Drawing.Point(329, 533);
            this.txtbxConfigPanNo.Name = "txtbxConfigPanNo";
            this.txtbxConfigPanNo.Size = new System.Drawing.Size(243, 22);
            this.txtbxConfigPanNo.TabIndex = 0;
            // 
            // txtbxConfigGSTNo
            // 
            this.txtbxConfigGSTNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbxConfigGSTNo.Location = new System.Drawing.Point(329, 566);
            this.txtbxConfigGSTNo.Name = "txtbxConfigGSTNo";
            this.txtbxConfigGSTNo.Size = new System.Drawing.Size(243, 22);
            this.txtbxConfigGSTNo.TabIndex = 0;
            // 
            // btnEditConfig
            // 
            this.btnEditConfig.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnEditConfig.CausesValidation = false;
            this.btnEditConfig.Location = new System.Drawing.Point(378, 598);
            this.btnEditConfig.Name = "btnEditConfig";
            this.btnEditConfig.Size = new System.Drawing.Size(144, 25);
            this.btnEditConfig.TabIndex = 2;
            this.btnEditConfig.Text = "Edit";
            this.btnEditConfig.UseVisualStyleBackColor = true;
            this.btnEditConfig.Click += new System.EventHandler(this.btnEditConfig_Click);
            // 
            // btnRemoveAll
            // 
            this.btnRemoveAll.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnRemoveAll.AutoSize = true;
            this.btnRemoveAll.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnRemoveAll.CausesValidation = false;
            this.btnRemoveAll.Location = new System.Drawing.Point(1270, 300);
            this.btnRemoveAll.Name = "btnRemoveAll";
            this.btnRemoveAll.Size = new System.Drawing.Size(89, 27);
            this.btnRemoveAll.TabIndex = 3;
            this.btnRemoveAll.Text = "Remove All";
            this.btnRemoveAll.UseMnemonic = false;
            this.btnRemoveAll.UseVisualStyleBackColor = true;
            this.btnRemoveAll.Click += new System.EventHandler(this.btnRemoveAll_Click);
            // 
            // btnSaveBill
            // 
            this.btnSaveBill.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSaveBill.Location = new System.Drawing.Point(1054, 572);
            this.btnSaveBill.Name = "btnSaveBill";
            this.tableLayoutPanel1.SetRowSpan(this.btnSaveBill, 2);
            this.btnSaveBill.Size = new System.Drawing.Size(147, 44);
            this.btnSaveBill.TabIndex = 4;
            this.btnSaveBill.Text = "Save Bill";
            this.btnSaveBill.UseVisualStyleBackColor = true;
            this.btnSaveBill.Click += new System.EventHandler(this.btnSaveBill_Click);
            this.btnSaveBill.Validating += new System.ComponentModel.CancelEventHandler(this.btnSaveBill_Validating);
            // 
            // dtpPubDate
            // 
            this.dtpPubDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpPubDate.CustomFormat = "dd/MM/yyyy";
            this.dtpPubDate.Location = new System.Drawing.Point(1015, 38);
            this.dtpPubDate.MaxDate = new System.DateTime(2250, 12, 31, 0, 0, 0, 0);
            this.dtpPubDate.MinDate = new System.DateTime(1950, 1, 1, 0, 0, 0, 0);
            this.dtpPubDate.Name = "dtpPubDate";
            this.dtpPubDate.Size = new System.Drawing.Size(226, 22);
            this.dtpPubDate.TabIndex = 5;
            // 
            // cbPaymentTerm
            // 
            this.cbPaymentTerm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.cbPaymentTerm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPaymentTerm.FormattingEnabled = true;
            this.cbPaymentTerm.Items.AddRange(new object[] {
            "Credit",
            "Pre-Payment"});
            this.cbPaymentTerm.Location = new System.Drawing.Point(1015, 136);
            this.cbPaymentTerm.Name = "cbPaymentTerm";
            this.cbPaymentTerm.Size = new System.Drawing.Size(226, 24);
            this.cbPaymentTerm.TabIndex = 6;
            // 
            // BillValidator
            // 
            this.BillValidator.ContainerControl = this;
            // 
            // BillGeneration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1385, 664);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "BillGeneration";
            this.Text = "BillGeneration";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.BillGeneration_FormClosing);
            this.Load += new System.EventHandler(this.BillGeneration_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BillValidator)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox txtbxInvoiceNo;
        private System.Windows.Forms.TextBox txtbxReleaseOrder;
        private System.Windows.Forms.TextBox txtbxCustomerName;
        private System.Windows.Forms.TextBox txtbxAddress;
        private System.Windows.Forms.TextBox txtbxGSTTin;
        private System.Windows.Forms.TextBox txtbxConfigGSTNo;
        private System.Windows.Forms.TextBox txtbxConfigPanNo;
        private System.Windows.Forms.TextBox txtbxConfigIFSCCode;
        private System.Windows.Forms.TextBox txtbxConfigAccountNo;
        private System.Windows.Forms.TextBox txtbxConfigBranchCode;
        private System.Windows.Forms.TextBox txtbxConfigBankName;
        private System.Windows.Forms.TextBox txtbxConfigCompanyName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblInsertions;
        private System.Windows.Forms.Label lblRate;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.TextBox txtbxClientName;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtbxIgst;
        private System.Windows.Forms.TextBox txtbxSGST;
        private System.Windows.Forms.TextBox txtbxCgst;
        private System.Windows.Forms.TextBox txtbxAgencyDiscount;
        private System.Windows.Forms.TextBox txtbxTotalAmount;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnEditConfig;
        private System.Windows.Forms.Button btnRemoveAll;
        private System.Windows.Forms.Button btnSaveBill;
        private System.Windows.Forms.ErrorProvider BillValidator;
        private System.Windows.Forms.DateTimePicker dtpPubDate;
        private System.Windows.Forms.ComboBox cbPaymentTerm;
    }
}