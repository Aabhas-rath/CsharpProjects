﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Windows.Forms;

namespace BillingPresentation
{
    public partial class LogIn : Form
    {
        private Dictionary<string, string> userAndPasswords = null;
        public LogIn()
        {
            InitializeComponent();
            init();
        }
        private void init()
        {
            userAndPasswords= new Dictionary<string, string>();
            foreach (var item in ConfigurationManager.AppSettings["users"].Split(';'))
            {
                if (!string.IsNullOrEmpty(item))
                {
                    userAndPasswords.Add(item.Split(':')[0], item.Split(':')[1]);
                }
                
            }
        }
        private void BtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (userAndPasswords==null)
            {
                return;
            }
            if (userAndPasswords.ContainsKey(txtbxUname.Text))
            {
                if (string.Equals(userAndPasswords[txtbxUname.Text],txtbxPassword.Text))
                {
                    MainPage mainPage = new MainPage();
                    mainPage.Show(this);
                    this.Hide();
                }
                else
                {
                    return;
                }
            }
            else
            {
                return;
            }
        }
    }
}
