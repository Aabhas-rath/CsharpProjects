﻿using System;
using System.IO;
using Billing.Models;
using BillingDatabaseContext;
using System.Linq;
using GemBox.Spreadsheet;
using System.Collections.Generic;

namespace BillingBusinessLogic
{

    public class BillPageGenerator : IDisposable
    {
        #region Properties
        public BaseBill AssociatedBill { get; set; }
        public Configuration Config { get; set; }
        public String BillSavePath { get; set; }
        public String BillTemplatePath { get; set; }
        public ConvertFileType ConvertFileType { get; set; }
        public String LogBasePath { get; set; }
        #endregion

        #region Variables
        private ExcelDBHandler context = null;
        private ExcelFile templateFile = null;
        private bool ConfigLoaded = false;
        private bool ContextLoaded = false;
        #endregion

        #region Public Methods

        #region Loading Excel Template of Bill

        public bool LoadTemplate(string path)
        {
            if (!String.IsNullOrEmpty(path))
            {
                SpreadsheetInfo.SetLicense("FREE-LIMITED-KEY");
                templateFile = ExcelFile.Load(path);
                context = new ExcelDBHandler();
                context.LoadLogFile(CreateLogFilePathFordate(LogBasePath, DateTime.Now));
                BillTemplatePath = path;
            }
            else
            {
                return false;
            }
            return true;

        }
        public bool LoadTemplate()
        {
            return LoadTemplate(BillTemplatePath);
        }

        #endregion

        #region Bill Generation

        public Byte[] GenerateBillByTemplate(string TemplatePath, string logbasepath, BaseBill bill, Configuration config)
        {
            LoadTemplate(TemplatePath);
            InsertConfigIntoTemplate(config, TemplatePath);
            InsertBillIntoTemplate(bill, config, TemplatePath);
            Byte[] output;
            using (MemoryStream stream = new MemoryStream())
            {
                var optns = SaveOptions.XlsxDefault;
                templateFile.Save(stream, optns);
                output = stream.ToArray();
            }
            LogBill(logbasepath, bill);
            return output;
        }
        public Byte[] GenerateBillByTemplate()
        {
            return GenerateBillByTemplate(BillTemplatePath, LogBasePath, AssociatedBill, Config);
        }
        #endregion

        #region Save Bill as
        public bool SaveBillAs(Byte[] GeneratedBill, ConvertFileType Type, string savePath)
        {
            ExcelFile excelfile;
            using (MemoryStream s = new MemoryStream(GeneratedBill))
            {
                excelfile = ExcelFile.Load(s);
            }
            switch (Type)
            {
                case ConvertFileType.HTML:
                    {
                        var optns = SaveOptions.HtmlDefault;
                        optns.SelectionType = SelectionType.ActiveSheet;
                        optns.HtmlType = HtmlType.Html;
                        optns.EmbedImages = true;

                        try
                        {
                            excelfile.Save(savePath, optns);
                        }
                        catch (Exception)
                        {

                            throw;
                        }
                    }
                    break;
                case ConvertFileType.PDF:
                    {
                        var optns = SaveOptions.PdfDefault;
                        optns.SelectionType = SelectionType.ActiveSheet;
                        try
                        {
                            excelfile.Save(savePath, optns);
                        }
                        catch (Exception)
                        {

                            throw;
                        }
                    }
                    break;
                case ConvertFileType.Xlsx:
                    {
                        var optns = SaveOptions.XlsxDefault;
                        optns.Type = XlsxType.Xlsx;

                        try
                        {
                            excelfile.Save(savePath, optns);

                        }
                        catch (Exception)
                        {

                            throw;
                        } }
                    break;
                case ConvertFileType.JPG:
                    {
                        var optns = SaveOptions.ImageDefault;
                        optns.SelectionType = SelectionType.ActiveSheet;
                        optns.Format = ImageSaveFormat.Jpeg;
                        try
                        {
                            excelfile.Save(savePath, optns);

                        }
                        catch (Exception)
                        {

                            throw;
                        } }
                    break;
                default:
                    return false;
            }
            return true;
        }
        public bool SaveBillAs(Byte[] GeneratedBill, string Type, string savePath)
        {
            switch (Type)
            {
                case "HTML":
                case "html":
                    return SaveBillAs(GeneratedBill, ConvertFileType.HTML, savePath);

                case "PDF":
                case "pdf":
                    return SaveBillAs(GeneratedBill, ConvertFileType.PDF, savePath);

                case "Image":
                case "JPG":
                case "jpeg":
                    return SaveBillAs(GeneratedBill, ConvertFileType.JPG, savePath);

                default:
                    return false;
            }
        }
        public void SaveBillAs(byte[] GeneratedBill)
        {
            SaveBillAs(GeneratedBill, ConvertFileType, BillSavePath);
        }
        #endregion

        #region Searching bills
        public BaseBill SearchBillByInvoiceNumber(string InvoiceNumber, string basPath)
        {
            BaseBill returnObject = null;
            foreach (var file in Directory.EnumerateFiles(basPath, "*.xlsx", SearchOption.TopDirectoryOnly))
            {
                using (context = new ExcelDBHandler())
                {
                    context.LoadLogFile(file);
                    returnObject = context.SearchBillByInvoiceNumber(InvoiceNumber);
                    break;
                }
            }
            return returnObject;
        }
        public BaseBill SearchBillByInvoiceNumber(string InvoiceNumber)
        {
            return SearchBillByInvoiceNumber(InvoiceNumber, LogBasePath);
        }

        public BaseBill SearchBillById(int Id, string basPath)
        {
            BaseBill returnObject = null;
            foreach (var file in Directory.EnumerateFiles(basPath, "*.xlsx", SearchOption.TopDirectoryOnly))
            {
                using (context = new ExcelDBHandler())
                {
                    context.LoadLogFile(file);
                    returnObject = context.SearchBillById(Id);
                    break;
                }
            }
            return returnObject;
        }
        public BaseBill SearchBillById(int Id)
        {
            return SearchBillById(Id, LogBasePath);

        }

        public List<BaseBill> SearchBillsByCustomername(string CustomerName, string basPath)
        {
            List<BaseBill> returnObject = new List<BaseBill>();
            foreach (var file in Directory.EnumerateFiles(basPath, "*.xlsx", SearchOption.TopDirectoryOnly))
            {
                using (context = new ExcelDBHandler())
                {
                    context.LoadLogFile(file);
                    returnObject.AddRange(context.SearchBillsByCustomerName(CustomerName));
                }
            }
            return returnObject;
        }
        public List<BaseBill> SearchBillsByCustomername(string CustomerName)
        {
            return SearchBillsByCustomername(CustomerName, LogBasePath);
        }

        public List<BaseBill> SearchBillsByClientname(string ClientName, string basPath)
        {
            List<BaseBill> returnObject = new List<BaseBill>();
            foreach (var file in Directory.EnumerateFiles(basPath, "*.xlsx", SearchOption.TopDirectoryOnly))
            {
                using (context = new ExcelDBHandler())
                {
                    context.LoadLogFile(file);
                    returnObject.AddRange(context.SearchBillsByClientName(ClientName));
                }
            }
            return returnObject;
        }
        public List<BaseBill> SearchBillsByClientname(string ClientName)
        {
            return SearchBillsByCustomername(ClientName, LogBasePath);
        }

        #endregion

        #region Load All Bills
        public List<BaseBill> LoadAllBills(string basPath)
        {
            List<BaseBill> returnObject = new List<BaseBill>();
            foreach (var file in Directory.EnumerateFiles(basPath, "*.xlsx", SearchOption.TopDirectoryOnly))
            {
                using (context = new ExcelDBHandler())
                {
                    context.LoadLogFile(file);
                    returnObject.AddRange(context.LoadAllBills());
                }
            }
            return returnObject;
        }
        public List<BaseBill> LoadAllBills() {
            return LoadAllBills(LogBasePath);
        }
        #endregion

        #endregion

        #region Private Methods

        private string CreateLogFilePathFordate(string basePath,DateTime date)
        {
            if (!Directory.Exists(basePath))
            {
                throw new DirectoryNotFoundException("Base Logging Path not found.\nPath = " + basePath);
            }
            return Path.Combine(basePath, "Log-" + date.ToString("MMM-yyyy")+".xlsx");
        }
        private void LogBill(string BaseLoggingPath,BaseBill bill)
        {
            var path = CreateLogFilePathFordate(BaseLoggingPath,DateTime.Now);
            if (File.Exists(path))
            {
                using (context = new ExcelDBHandler())
                {
                    context.LoadLogFile(path);
                    context.SaveBillToLogFile(bill); 
                }
            }
            else
            {
                using (context=new ExcelDBHandler())
                {
                    context.CreateNewLogFile(BaseLoggingPath, "Log-" + DateTime.Now.ToString("MMM-yyyy"));
                    context.SaveBillToLogFile(bill);
                }
            }
        }
        private void InsertConfigIntoTemplate(Configuration Config, string templatefilepath)
        {
            if (templateFile == null)
            {
                LoadTemplate(templatefilepath);
            }
            var worksheet = templateFile.Worksheets[0];
            int row, column;
            if (worksheet.Cells.FindText("[CompanyName]", false, true, out row, out column))
                worksheet.Cells[row, column].Value = Config.CompanyName.ToString();
            if (worksheet.Cells.FindText("[BankName]", false, true, out row, out column))
                worksheet.Cells[row, column].Value = Config.BankName.ToString();
            if (worksheet.Cells.FindText("[BankAccountNumber]", false, true, out row, out column))
                worksheet.Cells[row, column].Value = Config.BankAccountNumber.ToString();
            if (worksheet.Cells.FindText("[BranchNumber]", false, true, out row, out column))
                worksheet.Cells[row, column].Value = Config.BranchNumber.ToString();
            if (worksheet.Cells.FindText("[IFSCCode]", false, true, out row, out column))
                worksheet.Cells[row, column].Value = Config.IFSCCode.ToString();
            if (worksheet.Cells.FindText("[PANCode]", false, true, out row, out column))
                worksheet.Cells[row, column].Value = Config.PANCode.ToString();
            if (worksheet.Cells.FindText("[GSTNo]", false, true, out row, out column))
                worksheet.Cells[row, column].Value = Config.GSTNo;

            ConfigLoaded = true;
        }
        private void InsertBillIntoTemplate(BaseBill bill, Configuration config, string templatepath)
        {
            if (!ConfigLoaded)
            {
                InsertConfigIntoTemplate(config, templatepath);
            }
            var worksheetCells = templateFile.Worksheets[0].Cells;
            int row, column;

            if (worksheetCells.FindText("[Name]", false, true, out row, out column))
                worksheetCells[row, column].Value = bill.Name;
            if (worksheetCells.FindText("[Address]", false, true, out row, out column))
                worksheetCells[row, column].Value = bill.Address;

            if (worksheetCells.FindText("[ClientName]", false, true, out row, out column))
                worksheetCells[row, column].Value = bill.ClientName;
            if (worksheetCells.FindText("[InvoiceNumber]", false, true, out row, out column))
                worksheetCells[row, column].Value = bill.InvoiceNumber;
            if (worksheetCells.FindText("[TotalBill]", false, true, out row, out column))
                worksheetCells[row, column].Value = bill.TotalBill;

            switch (bill.BillType)
            {
                case "Advertisement":
                case "advertisement":
                case "Add":
                case "add":
                case "ad":
                case "Ad":
                    {
                        AdvertisementBill newbill = bill as AdvertisementBill;
                        if (worksheetCells.FindText("[ClientGSTNo]", false, true, out row, out column))
                            worksheetCells[row, column].Value = newbill.GSTNo;
                        if (worksheetCells.FindText("[PublicationDate]", false, true, out row, out column))
                            worksheetCells[row, column].Value = newbill.PublicationDate.ToString("dd/MM/yyyy");
                        if (worksheetCells.FindText("[ReleaseOrderNo]", false, true, out row, out column))
                            worksheetCells[row, column].Value = newbill.ReleaseOrderNo;
                        if (worksheetCells.FindText("[PaymentTerm]", false, true, out row, out column))
                            worksheetCells[row, column].Value = newbill.PaymentTerm;
                        if (worksheetCells.FindText("[CGST]", false, true, out row, out column))
                            worksheetCells[row, column].Value = newbill.CGST;
                        if (worksheetCells.FindText("[SGST]", false, true, out row, out column))
                            worksheetCells[row, column].Value = newbill.SGST;
                        if (worksheetCells.FindText("[IGST]", false, true, out row, out column))
                            worksheetCells[row, column].Value = newbill.IGST;
                        if (worksheetCells.FindText("[AgencyDiscount]", false, true, out row, out column))
                            worksheetCells[row, column].Value = newbill.AgencyDiscount;

                        int productRow = 11;
                        var worksheet = templateFile.Worksheets[0];
                        if (newbill.NumberOfProducts!=0)
                        {
                            worksheet.Rows.InsertCopy(productRow + 1, newbill.NumberOfProducts, worksheet.Rows[productRow]);
                        }
                        

                        for (int i = 0; i < newbill.NumberOfProducts; i++)
                        {

                            var currentRow = worksheet.Rows[productRow + i];
                            currentRow.Cells[2].SetValue(newbill.Products[i].Name);

                            currentRow.Cells[4].SetValue(newbill.Products[i].Quantity + " * " + newbill.Products[i].Rate);
                            currentRow.Cells[5].SetValue(newbill.Products[i].TotalAmount);
                            switch (newbill.Products[i].ProductType)
                            {
                                case "Views":
                                    {
                                        currentRow.Cells[3].SetValue("Views = " + (newbill.Products[i] as AdSpacePerViews).Views);
                                    }
                                    break;
                                case "Time":
                                    {
                                        currentRow.Cells[3].SetValue("From " + (newbill.Products[i] as AdSpacePerTime).From.ToString("dd/MM/yyyy")
                                            + " To " + (newbill.Products[i] as AdSpacePerTime).To.ToString("dd/MM/yyyy"));
                                    }
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    break;
                default:
                    break;
            }




        }


        #endregion

        public void Dispose()
        {
            AssociatedBill = null;
            Config = null;
            ConfigLoaded = false;
            BillSavePath = string.Empty;
            BillTemplatePath = string.Empty;
            ConvertFileType = ConvertFileType.Xlsx;
            LogBasePath = string.Empty;
            if (context!=null)
            {
                context.Dispose();
                context = null;
                ContextLoaded = false;
            }
            if (templateFile!=null)
            {
                templateFile = null;
            }
            
        }
    }
}
