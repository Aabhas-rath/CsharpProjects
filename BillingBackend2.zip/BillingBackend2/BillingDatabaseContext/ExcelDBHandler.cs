﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Billing.Models;

namespace BillingDatabaseContext
{
    public class ExcelDBHandler:IDisposable
    {
        #region Variables
        private static readonly object padlock = new object();
        private static ExcelDBHandler _ExcelDBHandlerInstance= null;
        private string _pathOfLogFile;
        private LogFile _loggingFile;

        #endregion

        public ExcelDBHandler ExcelDBHandlerInstance {
            get {
                lock (padlock)
                {
                    if (_ExcelDBHandlerInstance == null)
                    {
                        return new ExcelDBHandler();
                    }
                    return _ExcelDBHandlerInstance;
                }
            } }

        #region Public Methods

        public String PathOfLogFile { get => _pathOfLogFile; }
        public LogFile LoggingFile { get => _loggingFile; }

        public bool SaveBillToLogFile(BaseBill bill, LogFile file)
        {
            file.Logs.Add(bill);
            if (file.Save())
            {
                return true;
            }
            else
            {
                file.Logs.Remove(bill);
                return false;
            }
        }
        public void CreateNewLogFile(string BasePath,string name)
        {
            _loggingFile = new LogFile();
            _loggingFile.CreateNewLogFile(BasePath, name);
            _pathOfLogFile = System.IO.Path.Combine(BasePath, name+@".xlsx");
        }
        public bool SaveBillToLogFile(BaseBill bill)
        {
            return SaveBillToLogFile(bill, _loggingFile);
        }

        #region Log File Loading
        public LogFile LoadLogFile(string path)
        {
            if (File.Exists(path))
            {
                _loggingFile =new LogFile();
                _pathOfLogFile = path;
            }
            else
            {
                CreateNewLogFile(Path.GetDirectoryName(path), Path.GetFileName(path));
            }

            return LoggingFile;
        }
        public LogFile LoadLogFile()
        {
            return LoadLogFile(PathOfLogFile);
        }

        #endregion

        #region Searching and Filter
        public List<BaseBill> LoadAllBills(String path)
        {
            _loggingFile = LoadLogFile(path);
            return LoggingFile.Logs;
        }
        public List<BaseBill> LoadAllBills()
        {
            _loggingFile = LoadLogFile();
            return LoggingFile.Logs;
        }
        public BaseBill SearchBillByInvoiceNumber(String InvoiceNumber)
        {
            return LoadAllBills().First(m => string.Equals(m.InvoiceNumber.ToUpper(), InvoiceNumber.ToUpper()));
        }
        public BaseBill SearchBillById(int id)
        {
            return LoadAllBills().First(m => m.Id == id);
        }
        public List<BaseBill> SearchBillsByCustomerName(string CName)
        {
            return LoadAllBills().Where(m => string.Equals(m.Name.ToUpper(), CName.ToUpper())).ToList();
        }
        public List<BaseBill> SearchBillsByClientName(string CName)
        {
            return LoadAllBills().Where(m => string.Equals(m.ClientName.ToUpper(), CName.ToUpper())).ToList();
        }
        #endregion
        public void Dispose()
        {
            _loggingFile.Dispose();
            _loggingFile = null;
            _pathOfLogFile = string.Empty;
        }

        #endregion
    }
}
