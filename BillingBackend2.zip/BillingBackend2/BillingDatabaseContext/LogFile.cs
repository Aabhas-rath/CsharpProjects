﻿using System;
using System.Collections.Generic;
using System.IO;
using Billing.Models;
using System.Linq;
using GemBox.Spreadsheet;

namespace BillingDatabaseContext
{
    public class LogFile:IDisposable
    {

        #region Properties
        public String Name { get => _name;  }
        public FileInfo Information { get => _information;  }
        public DirectoryInfo CurrentDirectoryInfo { get => _currentDirectoryInfo;  }
        public DateTime RecentLogDate { get => _recentLogDate;  }
        public DateTime CreationDate { get => _creationDate;  }
        public TimeSpan LoggingPeriod { get => _loggingPeriod; }
        public int NumberOfLogs { get => _numberOfLogs;   }
        public List<BaseBill> Logs { get => _logs; }
        public String FullName { get => _fullName;  }
        #endregion

        #region Private Variables
        private ExcelFile logfile;
        private string _name;
        private FileInfo _information;
        private DirectoryInfo _currentDirectoryInfo;
        private DateTime _recentLogDate;
        private DateTime _creationDate;
        private TimeSpan _loggingPeriod;
        private int _numberOfLogs;
        private List<BaseBill> _logs;
        private string _fullName;
        private bool _LogFileLoaded=false;
        #endregion

        public LogFile(string filename)
        {
            SpreadsheetInfo.SetLicense("FREE-LIMITED-KEY");
            Load(filename);
        }
        public LogFile()
        {
            SpreadsheetInfo.SetLicense("FREE-LIMITED-KEY");
        }

        #region Public Methods

        public void CreateNewLogFile(string Directory,string filename)
        {
            logfile = new ExcelFile();
            _fullName = Path.Combine(Directory, filename+@".xlsx");
            logfile.Worksheets.Add("Sheet1");
            logfile.Save(_fullName);
            _name = filename;
            _information = new FileInfo(_fullName);
            _currentDirectoryInfo = new DirectoryInfo(Directory);
            _recentLogDate = DateTime.Today;
            _creationDate = DateTime.Now;
            _loggingPeriod = _creationDate.Subtract(DateTime.Now);
            _logs = new List<BaseBill>();
            _numberOfLogs = 0;
        }
        public void Load()
        {
            Load(FullName);
        }
        public void reload() { reload(FullName); }
        public void reload(String Name) {
            Load(Name, true);
        }
        public void Load(String Name,bool dontreload=false)
        {
            if (_LogFileLoaded)
            {
                return;
            }
            else
            {
                 
                if (!File.Exists(Name))
                {
                    throw new FileNotFoundException("Log File Not Fount", Name);
                }
                else
                {
                    logfile = ExcelFile.Load(Name);
                    var worksheet = logfile.Worksheets[0];
                    _logs = new List<BaseBill>();
                    Logs.Clear();
                    foreach (var row in worksheet.Rows)
                    {
                        BaseBill bill = null;
                        if (row.AllocatedCells.Count==0)
                        {
                            continue;
                        }
                        switch (row.AllocatedCells.First(m => m.Column.Name=="B").Value)
                        {
                            case "Advertisement":
                            case "advertisement":
                            case "Add":
                            case "add":
                            case "ad":
                            case "Ad":
                                {
                                    bill = new AdvertisementBill(
                                        row.AllocatedCells.First(m => m.Column.Name==("E")).Value.ToString(),
                                        row.AllocatedCells.First(m => m.Column.Name == ("C")).Value.ToString(),
                                        row.AllocatedCells.First(m => m.Column.Name == ("D")).Value.ToString(),
                                        row.AllocatedCells.First(m => m.Column.Name == ("F")).Value.ToString(),
                                        Convert.ToInt32(row.AllocatedCells.First(m => m.Column.Name == ("H")).Value),
                                        row.AllocatedCells.First(m => m.Column.Name == ("G")).Value.ToString(),
                                        row.AllocatedCells.First(m => m.Column.Name == ("I")).Value.ToString(),
                                        row.AllocatedCells.First(m => m.Column.Name == ("J")).Value.ToString(),
                                        row.AllocatedCells.First(m => m.Column.Name == ("K")).Value.ToString(),
                                        row.AllocatedCells.First(m => m.Column.Name == ("L")).Value.ToString(),
                                        Convert.ToInt32(row.AllocatedCells.First(m => m.Column.Name == ("M")).Value),
                                        Convert.ToInt32(row.AllocatedCells.First(m => m.Column.Name == ("N")).Value),
                                        Convert.ToInt32(row.AllocatedCells.First(m => m.Column.Name == ("O")).Value),
                                        Convert.ToInt32(row.AllocatedCells.First(m => m.Column.Name == ("Q")).Value),
                                        new List<BaseProduct>()
                                        );
                                    for (int i = 0, j = 0; i < Convert.ToInt32(row.AllocatedCells.First(m => m.Column.Name == ("P")).Value); i++, j += 8)
                                    {
                                        BaseProduct product = null;
                                        switch (row.AllocatedCells.First(m => m.Column.Index == (18 + j)).Value)
                                        {
                                            case "Views":
                                                {
                                                    product = new AdSpacePerViews(
                                                        row.AllocatedCells.First(m => m.Column.Index == (18 + j)).Value.ToString(),
                                                        Convert.ToInt32(row.AllocatedCells.First(m => m.Column.Index == (20 + j)).Value),
                                                        Convert.ToDouble(row.AllocatedCells.First(m => m.Column.Index == (21 + j)).Value),
                                                        Convert.ToDouble(row.AllocatedCells.First(m => m.Column.Index == (22 + j)).Value),
                                                        Convert.ToInt64(row.AllocatedCells.First(m => m.Column.Index == (24 + j)).Value)
                                                        );
                                                }
                                                break;
                                            case "Time":
                                                {
                                                    product = new AdSpacePerTime(
                                                       row.AllocatedCells.First(m => m.Column.Index == (18 + j)).Value.ToString(),
                                                       Convert.ToInt32(row.AllocatedCells.First(m => m.Column.Index == (20 + j)).Value),
                                                       Convert.ToDouble(row.AllocatedCells.First(m => m.Column.Index == (21 + j)).Value),
                                                       Convert.ToDouble(row.AllocatedCells.First(m => m.Column.Index == (22 + j)).Value),
                                                       row.AllocatedCells.First(m => m.Column.Index == (23 + j)).Value.ToString(),
                                                       row.AllocatedCells.First(m => m.Column.Index == (24 + j)).Value.ToString()
                                                       );
                                                }
                                                break;
                                            default:
                                                break;
                                        }
                                        if (product != null)
                                        {
                                            (bill as AdvertisementBill).AddProductToProductsList(product);
                                        }
                                        else
                                            throw new Exception("Product Information absent");
                                    }

                                }
                                break;

                            default:
                                break;
                        }
                        if (bill != null)
                        {
                            Logs.Add(bill);
                        }
                        else
                            throw new Exception("Bill not added");
                    }

                    _recentLogDate = (Logs.Count!=0)?Logs.Max(m => m.InvoiceDate):DateTime.MinValue;
                    _loggingPeriod = (Logs.Count != 0) ? (Logs.Max(m => m.InvoiceDate).Subtract(Logs.Min(m => m.InvoiceDate))): TimeSpan.Zero;
                    try
                    {
                        _information = new FileInfo(Name);
                        _currentDirectoryInfo = new DirectoryInfo(Name);
                        _creationDate = _information.CreationTime.Date ;
                    }
                    catch (Exception)
                    {

                        throw;
                    }
                    _numberOfLogs = Logs.Count;
                    _fullName = Name;
                    _name = Path.GetFileName(Name);
                
                }
                _LogFileLoaded = true;
            }
        }
        public bool Save()
        {
            if (File.Exists(FullName))
            {
                File.Delete(FullName);
            }

            logfile = new ExcelFile();
            logfile.Worksheets.Add(Path.GetFileNameWithoutExtension(FullName));
            var ExcelSheet = logfile.Worksheets[0];
            ExcelSheet.Name = "Bills";
            int row = 1, id = 1;

            foreach (var bill in Logs.OrderBy(m => m.InvoiceDate))
            {
                ExcelSheet.Cells[row, 0].Value = id++;
                ExcelSheet.Cells[row, 1].Value = bill.BillType;
                ExcelSheet.Cells[row, 2].Value = bill.InvoiceNumber;
                ExcelSheet.Cells[row, 3].Value = bill.InvoiceDate;
                ExcelSheet.Cells[row, 4].Value = bill.Name;
                ExcelSheet.Cells[row, 5].Value = bill.ClientName;
                ExcelSheet.Cells[row, 6].Value = bill.Address;
                ExcelSheet.Cells[row, 7].Value = bill.TotalBill;
                switch (bill.BillType)
                {
                    case "Advertisement":
                    case "advertisement":
                    case "Add":
                    case "add":
                    case "ad":
                    case "Ad":
                        {
                            AdvertisementBill newbill = (bill as AdvertisementBill);
                            ExcelSheet.Cells[row, 8].Value = newbill.GSTNo;
                            ExcelSheet.Cells[row, 9].Value = newbill.PublicationDate;
                            ExcelSheet.Cells[row, 10].Value = newbill.ReleaseOrderNo;
                            ExcelSheet.Cells[row, 11].Value = newbill.PaymentTerm;
                            ExcelSheet.Cells[row, 12].Value = newbill.CGST;
                            ExcelSheet.Cells[row, 13].Value = newbill.SGST;
                            ExcelSheet.Cells[row, 14].Value = newbill.IGST;
                            ExcelSheet.Cells[row, 15].Value = newbill.NumberOfProducts;
                            ExcelSheet.Cells[row, 16].Value = newbill.AgencyDiscount;

                            for (int i = 0; i < newbill.NumberOfProducts; i++)
                            {
                                ExcelSheet.Cells[row, (17 + i * 8)].Value = newbill.Products[i].Name;
                                ExcelSheet.Cells[row, (18 + i * 8)].Value = newbill.Products[i].ProductType;
                                ExcelSheet.Cells[row, (19 + i * 8)].Value = newbill.Products[i].Quantity;
                                ExcelSheet.Cells[row, (20 + i * 8)].Value = newbill.Products[i].Rate;
                                ExcelSheet.Cells[row, (21 + i * 8)].Value = newbill.Products[i].TotalAmount;
                                switch (newbill.Products[i].ProductType)
                                {
                                    case "Views":
                                        {
                                            ExcelSheet.Cells[row, (24 + i * 8)].Value = (newbill.Products[i] as AdSpacePerViews).Views;
                                        }
                                        break;
                                    case "Time":
                                        {
                                            ExcelSheet.Cells[row, (22 + i * 8)].Value = (newbill.Products[i] as AdSpacePerTime).From;
                                            ExcelSheet.Cells[row, (23 + i * 8)].Value = (newbill.Products[i] as AdSpacePerTime).To;
                                        }
                                        break;
                                    default:
                                        break;
                                }

                            }

                        }
                        break;
                    default:
                        break;
                }


                row++;
            }

            try
            {
                var opt = SaveOptions.XlsxDefault;
                logfile.Save(FullName,opt);
            }
            catch (Exception)
            {
                return false;
            }
            reload(FullName);
            return true;

        }
        public void Dispose()
        {
            Logs.Clear();
            _name = string.Empty;
            _information = null;
            _currentDirectoryInfo = null;
            _logs.Clear();
            _fullName = string.Empty;
        }

        #endregion
    }
}
