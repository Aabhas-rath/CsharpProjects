﻿using System;

namespace Billing.Models
{
    public class AdSpacePerTime:BaseProduct
    {
        public DateTime From { get; set; }
        public DateTime To { get; set; }
        

        public TimeSpan GetDurationOfAdd()
        {
            return To.Subtract(From);
        }
        public AdSpacePerTime(string name, int quan, double rate, double amount, string from, string to)
        {
            Name = name;
            ProductType = "Time";
            Quantity = quan;
            Rate = rate;
            TotalAmount = amount;
            From = DateTime.ParseExact(from, "dd/MM/yyyy", null);
            To = DateTime.ParseExact(to, "dd/MM/yyyy", null);
        }
        public AdSpacePerTime(string name, int quan, double rate, double amount, DateTime from, DateTime to)
        {
            Name = name;
            Quantity = quan;
            Rate = rate;
            TotalAmount = amount;
            From = from;
            To = to;
        }

    }
}
