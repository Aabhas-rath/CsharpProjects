﻿using System;

namespace Billing.Models
{
    abstract public class BaseProduct
    {
        public string Name { get; set; }
        public String ProductType { get; set; }
        public int Quantity { get; set; }
        public double Rate { get; set; }
        public double TotalAmount { get; set; }

    }
}
