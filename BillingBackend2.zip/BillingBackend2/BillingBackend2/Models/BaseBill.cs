﻿using System;

namespace Billing.Models
{
    abstract public class BaseBill
    {
        public int Id { get; set; }
        public String BillType { get; set; }
        public String InvoiceNumber { get; set; }
        public DateTime InvoiceDate { get; set; }
        public String Name { get; set; }
        public String ClientName { get; set; }
        public String Address { get; set; }
        public int TotalBill { get; set; }

    }
}
