﻿namespace Billing.Models
{
    public class AdSpacePerViews :BaseProduct
    {
        public long Views { get; set; }
        public AdSpacePerViews(string name, int quan, double rate, double amount,long views)
        {
            ProductType = "Views";
            Name = name;
            Quantity = quan;
            Rate = rate;
            TotalAmount = amount;
            Views = views;
        }
        public long IncrementViews()
        {
            return ++Views;
        }

    }
}
