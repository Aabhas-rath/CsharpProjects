﻿using System;
using System.Collections.Generic;

namespace Billing.Models
{
    public class AdvertisementBill:BaseBill
    {
        public String GSTNo { get; set; }
        public DateTime PublicationDate { get; set; }
        public String ReleaseOrderNo { get; set; }
        public String PaymentTerm { get; set; }
        public double CGST { get; set; }
        public double SGST { get; set; }
        public double IGST { get; set; }
        public int AgencyDiscount { get; set; }
        public int NumberOfProducts { get { return Products.Count; } }
        public List<BaseProduct> Products { get; set; }

        public AdvertisementBill(string name,string invoiceno,DateTime invoicedate,string cname,
            int totalbill, string address,string gst,DateTime pdate, string release,string paymentterm,double cgst, 
            double sgst, double igst, int agentdiscount,List<BaseProduct> ps)
        {
            BillType = "Advertisement";
            Name = name;
            InvoiceNumber = invoiceno;
            InvoiceDate = invoicedate;
            ClientName = cname;
            TotalBill = totalbill;
            Address = address;
            GSTNo = gst;
            PublicationDate = pdate;
            PaymentTerm = paymentterm;
            CGST = cgst;
            SGST = sgst;
            IGST = igst;
            AgencyDiscount = agentdiscount;
            Products = ps;
        }

        public AdvertisementBill(string name, string invoiceno, string invoicedate, string cname,
            int totalbill, string address, string gst, string pdate, string release, string paymentterm, double cgst,
            double sgst, double igst, int agentdiscount, List<BaseProduct> ps)
        {
            BillType = "Advertisement";
            Name = name;
            InvoiceNumber = invoiceno;
            InvoiceDate = DateTime.Parse(invoicedate);
            ClientName = cname;
            TotalBill = totalbill;
            Address = address;
            GSTNo = gst;
            PublicationDate = DateTime.Parse(pdate); 
            PaymentTerm = paymentterm;
            CGST = cgst;
            SGST = sgst;
            IGST = igst;
            AgencyDiscount = agentdiscount;
            Products = ps;
        }
        public AdvertisementBill()
        {

        }

        public void AddProductToProductsList(BaseProduct product)
        {
            if (Products==null)
            {
                Products = new List<BaseProduct>();
                Products.Clear();
                Products.Add(product);
            }
            else
            {
                if (product.TotalAmount < TotalBill)
                {
                    Products.Add(product);
                }
                else
                {
                    throw new Exception("Product = " + product.Name + ".\nProduct amount Greater than Bill Amount.\nPlease check.");
                }
            }
        }
    }
}
