﻿using System;

namespace Billing.Models
{
    public enum ConvertFileType
    {
        HTML,
        PDF,
        Xlsx,
        JPG
    }
    public class Configuration
    {
        #region Variables
        private string _bankName;
        private int _branchNumber;
        private string _bankAccountNumber;
        private string _ifsccode;
        private string _companyName;
        private string _PANCode;
        private string _gstno;
        #endregion

        public Configuration(string name, string acno, string ifsccode, int branchNo, string Cname, string panCode, string gst)
        {
            _bankName = name;
            _bankAccountNumber = acno;
            _ifsccode = ifsccode;
            _branchNumber = branchNo;
            _companyName = Cname;
            _gstno = gst;
            _PANCode = panCode;
        }


        #region Getters
        public String CompanyName { get { return _companyName; } }
        public String BankName { get { return _bankName; } }
        public String BankAccountNumber { get { return _bankAccountNumber; } }
        public int BranchNumber { get { return _branchNumber; } }
        public String IFSCCode { get { return _ifsccode; } }
        public String PANCode { get { return _PANCode; } }
        public String GSTNo { get { return _gstno; } }
        #endregion

        public bool ChangeBankInfo(string name, string acno, string ifsccode, int branchNo)
        {
            try
            {
                _bankName = name;
                _bankAccountNumber = acno;
                _ifsccode = ifsccode;
                _branchNumber = branchNo;
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        public bool ChangeCompanyInfo(string Cname, string panCode, string gst)
        {
            try
            {
                _companyName = Cname;
                _gstno = gst;
                _PANCode = panCode;
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }
    }
}
